<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>無標題文件</title>
</head>

<body>
<form action="down2_excel.php" method="post" name="form1" target="_blank" id="form1">
                <tr>
                  <td colspan="2" class="no_data"><p>點選下方按鈕,可下載會員名單(為csv檔案,可用excel開啟)</p>
                    <p>
                      <input type="submit" name="submit" id="submit" value="送出" />
                    </p></td>
                </tr>
                <tr>
                  <td width="185">&nbsp;</td>
                  <td width="615"><input name="outexcel" type="hidden" id="outexcel" value="1" /></td>
                </tr>
              </form>
</body>
</html>
